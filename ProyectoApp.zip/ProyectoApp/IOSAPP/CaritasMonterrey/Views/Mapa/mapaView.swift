//
//  FullMapView.swift
//  test
//
//  Created by Victor Valero on 06/10/25.
//

import SwiftUI
import MapKit
import CoreLocation

//puntos en el mapa
extension CLLocationCoordinate2D {
    static let bazar1 = CLLocationCoordinate2D(latitude: 25.679263, longitude: -100.340499)
    static let bazar2 = CLLocationCoordinate2D(latitude: 25.682716, longitude: -100.310453)
    static let bazar3 = CLLocationCoordinate2D(latitude: 25.784040, longitude: -100.407145)
    static let bazar4 = CLLocationCoordinate2D(latitude: 25.699485, longitude: -100.460740)
    static let bazar5 = CLLocationCoordinate2D(latitude: 25.659183, longitude: -100.368712)
    static let bazar6 = CLLocationCoordinate2D(latitude: 25.674526, longitude: -100.258442)
}


struct mapaView: View {
    @State private var position: MapCameraPosition = .userLocation(fallback: .automatic)
    @State private var locationManager = CLLocationManager()
    @Environment(\.dismiss) private var dismiss
    
    @State private var fullMap = true

    var body: some View {
        NavigationStack {
            //map
            VStack {
                Map(position: $position) {
                    UserAnnotation()
                    
                    Annotation("Bazar Cáritas, Monterrey", coordinate: .bazar1) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                    Annotation("Bazar Cáritas, Centro", coordinate: .bazar2) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                    Annotation("Bazar Cáritas, Col. Trazo Marco", coordinate: .bazar3) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                    Annotation("Bazar Cáritas, San Gilberto", coordinate: .bazar4) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                    Annotation("Bazar Cáritas, San Pedro", coordinate: .bazar5) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                    Annotation("Bazar Cáritas, Centro Guadalupe ", coordinate: .bazar6) {
                        BubbleAnnotationLabel(icon: "building.2.fill")
                    }
                }
                .mapStyle(.standard(elevation: .realistic))
                .onAppear {
                    locationManager.requestWhenInUseAuthorization()
                }
                .mapControls {
                    if fullMap {
                        MapUserLocationButton()
                    }
                }
            }

            }
        }
    }


//diseño para los puntos
struct BubbleAnnotationLabel: View {
    let icon: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.headline)
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(red: 1.0, green: 0.40, blue: 0.60), // rosa
                            Color(red: 1.0, green: 0.10, blue: 0.40)  // fucsia
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(.white.opacity(0.25), lineWidth: 0.8)
        )
        .shadow(color: .black.opacity(0.25), radius: 12, x: 0, y: 6)
    }
}

#Preview {
    mapaView()
}
