//
//  OnboardingViewModel.swift
//  CaritasMonterrey
//
//  Created by Alumno on 20/10/25.
//

import Foundation
import Combine

import Foundation
final class ProfileViewModel: ObservableObject {}

